<!DOCTYPE html>
<html lang="sk">
<head>
	<meta charset="UTF-8">
	<title>NiXuŠ - XichtMaker</title>
	<script src="https://rawgit.com/G43riko/Utils/master/Components/G/g.js"></script>
	
	<link rel="stylesheet" type="text/css" href="styles2.css">
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Sacramento" rel="stylesheet">
</head>
<body>
	<?php include("header.php"); ?>
	<div class="container" id="imagesContent">
		<?php for($i=0 ; $i<20 ; $i++){ ?>
		<div class="imageWrapper">
			<img src="img/img1.jpg" alt="">
			<div>
				<p>Krátky popisok</p>
			</div>
		</div>
		<div class="imageWrapper">
			<img src="img/img2.jpg" alt="">
			<div>
				<p>Krátky popisok</p>
			</div>
		</div>
		<div class="imageWrapper">
			<img src="img/img3.jpg" alt="">
			<div>
				<p>Krátky popisok</p>
			</div>
		</div>
		<div class="imageWrapper">
			<img src="img/img4.jpg" alt="">
			<div>
				<p>Krátky popisok</p>
			</div>
		</div>
		<div class="imageWrapper">
			<img src="img/img5.jpg" alt="">
			<div>
				<p>Krátky popisok</p>
			</div>
		</div>
		<div class="imageWrapper">
			<img src="img/img6.jpg" alt="">
			<div>
				<p>Krátky popisok</p>
			</div>
		</div>
		<div class="imageWrapper">
			<img src="img/img7.jpg" alt="">
			<div>
				<p>Krátky popisok</p>
			</div>
		</div>
		<?php }; ?>
	</div>
</body>
<script type="text/javascript">
	(function(){
		function hideImage(e, img){
			if(e.target === img){
				G(img).removeClass("visible");
				setTimeout(() => G.delete(img), 1000);
			}
		}
		function showNextImage(image, fullImage){
			var wrapper = G(image).parent()
			if(wrapper.is(":last-child ")){
				//fullImage.first().attr("src", )
				var bg = document.getElementById("imageBackground");
				hideImage({target: bg}, bg);
			}
			else{
				var imgNew = wrapper.next().childrens();
				G(fullImage).attr("src", imgNew.attr("src"));
				fullImage.onclick = function(){showNextImage(imgNew.first(), fullImage);}
			}
		}
		function showImage(img){
			var image = new G("img", {attr: {
				src: img.src, 
				id: "frontImage"
			}});/*.click(function(){
				showNextImage(img, this);
			});
			*/
			image.first().onclick = function(){
				showNextImage(img, this);
			}

			var el = G("div", {
				attr:{id: "imageBackground"},
				cont: image
			}).appendTo(document.body);
			el.click(e => {
				hideImage(e, el.first());
			}).delay(() => el.addClass("visible"));
		}
		G(".imageWrapper img").each(function(){
			G(this).click(function(e){
				showImage(e.target);
			});
		});
	})();
	
</script>
</html>