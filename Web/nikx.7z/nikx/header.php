<div id="header">
	<div class="container">
		<div class="headerPanel">
			<nav>
				<ul>
					<li>
						<a href=".">DOMOV</a>
					<!--
						TODO vkladanie fotiek používatelmi
					-->
					</li>
					<li>
						<a href="">KONTAKT</a>
						<ul id="contactMenu">
							<li>
								<img src="https://img.clipartfest.com/5b8dfb6057ad2946021c0b7833e0cdc8_check-us-out-on-transparent-instagram-clipart_800-799.png" alt="">
								<a href="https://www.instagram.com/nikaholla/">INSTAGRAM</a>
							</li>
							<li>
								<img src="https://img.clipartfest.com/173aea471f8f1d8e5ca136466647f06f_0b7753270e697519ee9e295288925d-facebook-clipart-transparent-background_1000-1000.png" alt="">
								<a href="https://www.facebook.com/nikusa.holla">FACEBOOK</a>
							</li>
							<li>
								<img src="https://cdn2.iconfinder.com/data/icons/squareplex/512/gmail.png" alt="">
								<!--
								<a href="https://plus.google.com/118191153847702192677">GMAIL</a>
								-->
								<a href="mailto:hollanikola@gmail.com">GMAIL</a>
							</li>
						</ul>
					</li>
				</ul>
			</nav>
		</div>
		<div class="headerPanel">
			<h1>NIXUŠ</h1>
			<h1 id="kisskiss" style="margin-top:-49px;">🗢</h1>
			<h2 style="margin-top:-8px;">Professional Xichtstyler</h2>
		</div>
		<div class="headerPanel">
			<nav>
				<ul>
					<li><a href="galery.php">GALÉRIA</a></li>
					<li>
						<a href="">VIDEÁ</a>
						<ul>
							<li>
								<a href="tutorials.php">Tutoriály</a>
							</li>
							<li>
								<a href="bumerangs.php">Bumerangy</a>
							</li>
						</ul>
					</li>
				</ul>
			</nav>
		</div>
	</div>
</div>